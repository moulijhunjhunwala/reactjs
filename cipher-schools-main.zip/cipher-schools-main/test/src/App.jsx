import ItemScreen from './components/ItemScreen'

function App() {
    return (
        <div className="App">
            <ItemScreen />
        </div>
    )
}

export default App
