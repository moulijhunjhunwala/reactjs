import './App.css';

function App() {
  return (
    <span className="cipher">
      <h1>Something</h1>
      <h1>Good</h1>
      <h1>Here</h1>
    </span>
  );
}

export default App;
